
1. Open server.js file.
2. Make the changes w.r.t. dynamically handled routes using HTTP Module
   as seen in the file. 
3. After learning express; we will be moving and adding few more routes 
   to routes folder - for better maintainance.

4. Run command node server.js
 
5. Ensure calling http://localhost:9000/movies 
   shows "All Movies Data in JSON format from Mongo DB" in browser.  
6. Ensure calling http://localhost:9000/genres 
   shows "All Genres Data in JSON format from Mongo DB" in browser.  
7. Ensure calling http://localhost:9000/artists 
   shows "All Artists Data in JSON format from Mongo DB" in browser.  

8. For Reference; Browser snapshot can be seen in screenshots folder.
   Kindly refer: Route_Call_in_Browser.png

