-- Check point 8
-- Code w.r.t. booking a show


1. Complete code for handling route(s) 
    /getCouponCode 
    /bookShow 
    in app/controllers/user.controller.js


2. Ensure respective addition(s) are updates in "app/routes/user.routes.js"
